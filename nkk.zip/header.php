<?php
/**
 * The header for our theme.
 *
 * @package nkk
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="ie=edge">

<!-- フォント -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant:wght@400;500;600;700&family=Fjalla+One&family=Noto+Sans+JP:wght@300;400;500;700&family=Noto+Serif+JP:wght@400;500;600;700&display=swap" rel="stylesheet">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

<!-- ロード -->
<div id="loading"></div>

<!-- スマホメニュー -->
<div id="nav" class="--tab-sp">
	<nav class="cntInner">
		<ul class="cntList _Nav --h-opacity">
			<?php $url = get_page_url("hct"); if($url): ?>
			<li><div class="js-slide"><a href="<?php echo $url; ?>" class="--bold">圧密加工</a></div>
				<ul>
					<li><a href="<?php echo $url."#_features"; ?>" class="link">圧密加工材の特徴</a></li>
					<li><a href="<?php echo $url."#_heating"; ?>" class="link">床暖房対応</a></li>
					<li><a href="<?php echo $url."#_process"; ?>" class="link">加工工程</a></li>
					<li><a href="<?php echo $url."#_mainteneance"; ?>" class="link">メンテナンス</a></li>
					<li><a href="<?php echo $url."#_business"; ?>" class="link">施工業者様へ</a></li>
				</ul>
			</li>
			<?php endif; ?>
			<?php $url = get_page_url("cp"); if($url): ?>
			<li><div class="js-slide"><a href="<?php echo $url; ?>" class="--bold">受託加工・賃加工</a></div>
				<ul>
					<li><a href="<?php echo $url; ?>" class="link">資料ダウンロード</a></li>
				</ul>
			</li>
			<?php endif; ?>
			<?php $url = get_page_url("works_2"); if($url): ?>
			<li><div class="js-slide"><a href="<?php echo $url; ?>" class="--bold">施工事例</a></div>
				<ul>
					<li><a href="<?php echo $url; ?>" class="link">住宅・店舗施工例</a></li>
					<?php $url = get_page_url("works"); if($url): ?>
					<li><a href="<?php echo $url; ?>" class="link">公共物件施工例</a></li>
					<?php endif; ?>
				</ul>
			</li>
			<?php endif; ?>
			<?php $url = get_page_url("appeal"); if($url): ?>
			<li><div class="js-slide"><a href="<?php echo $url; ?>" class="--bold">木材の魅力</a></div>
				<ul>
					<li><a href="<?php echo $url."#_appeal-02"?>" class="link">杉の魅力</a></li>
					<li><a href="<?php echo $url."#_appeal-03"?>" class="link">桧の魅力</a></li>
					<li><a href="<?php echo $url."#_domestic"?>" class="link">人と環境に優しい国産材</a></li>
				</ul>
			</li>
			<?php endif; ?>
			<?php $url = get_page_url("about"); if($url): ?>
			<li><div class="js-slide"><a href="<?php echo $url; ?>" class="--bold">組合概要</a></div>
				<ul>
					<li><a href="<?php echo $url."#_about"; ?>" class="link">Jスマイル内装材協同組合について</a></li>
					<li><a href="<?php echo $url."#_greeting"; ?>" class="link">ご挨拶</a></li>
					<li><a href="<?php echo $url."#_overview"; ?>" class="link">組合概要</a></li>
					<li><a href="<?php echo $url."#_philosophy"; ?>" class="link">経営理念</a></li>
					<li><a href="<?php echo $url."#_vision"; ?>" class="link">経営ビジョン</a></li>
					<li><a href="<?php echo $url."#_access"; ?>" class="link">アクセス</a></li>
				</ul>
			</li>
			<?php endif; ?>
			<li><a href="<?php echo home_url("#_catalog"); ?>" class="--bold">商品カタログ</a></li>
			<?php $url = get_page_url("faq"); if($url): ?>
			<li><a href="<?php echo $url; ?>" class="--bold">よくある質問</a></li>
			<?php endif; ?>
			<li><a href="<?php echo home_url("news"); ?>" class="--bold --ff-en">NEWS</a></li>
			<li><a href="https://www.youtube.com/channel/UCROBL0SwmuyeUnrxZuBxfaQ" class="--bold --ff-en" target="_blank" rel="noopener">YOUTUBE<span class="icon"></span></a></li>
			<?php $url = get_page_url("privacy"); if($url): ?>
			<li><a href="<?php echo $url; ?>" class="link">プライバシーポリシー</a></li>
			<?php endif; ?>
		</ul>
	</nav>
</div>

<!-- ヘッダー -->
<header id="header">
	<div class="cntInner">
		<a id="headerLogo" class="--h-opacity" href="<?php echo home_url(); ?>"><h1><img src="<?php echo get_template_directory_uri(); ?>/img/common/logo.svg" class="--img-contain white" alt="Jスマイル 内装材協同組合"><img src="<?php echo get_template_directory_uri(); ?>/img/common/logo-black.svg" class="--img-contain black" alt="Jスマイル 内装材協同組合"></h1></a>
		<!-- ナビメニュー -->
		<div class="cntBox">
			<ul class="cntList --pc">
				<?php $url = get_page_url("hct"); if($url): ?>
				<li class=""><a href="<?php echo $url; ?>" class="item"><span class="txt">圧密加工</span></a>
					<ul class="list --h-opacity">
						<li><a href="<?php echo $url."#_features"; ?>"><span class="txt">圧密加工</span></a></li>
						<li><a href="<?php echo $url."#_heating"; ?>"><span class="txt">加工工程</span></a></li>
						<li><a href="<?php echo $url."#_process"; ?>"><span class="txt">商品カタログ</span></a></li>
						<li><a href="<?php echo $url."#_mainteneance"; ?>"><span class="txt">メンテナンス</span></a></li>
						<li><a href="<?php echo $url."#_business"; ?>"><span class="txt">施工業者様へ</span></a></li>
					</ul>
				</li>
				<?php endif; ?>
				<?php $url = get_page_url("cp"); if($url): ?>
				<li class=""><a href="<?php echo $url; ?>" class="item"><span class="txt">受託加工・<br class="br">賃加工</span></a></li>
				<?php endif; ?>
				<?php $url = get_page_url("works_2"); if($url): ?>
				<li class=""><a href="<?php echo $url; ?>" class="item"><span class="txt">施工事例</span></a>
					<ul class="list --h-opacity">
						<li><a href="<?php echo $url; ?>"><span class="txt">住宅・店舗施工例</span></a></li>
						<?php $url = get_page_url("works"); if($url): ?>
						<li><a href="<?php echo $url; ?>"><span class="txt">公共物件施工例</span></a></li>
						<?php endif; ?>
					</ul>
				</li>
				<?php endif; ?>
				<?php $url = get_page_url("appeal"); if($url): ?>
				<li class=""><a href="<?php echo $url; ?>" class="item"><span class="txt">木材の<br class="br">魅力</span></a>
					<ul class="list --h-opacity">
						<li><a href="<?php echo $url."#_appeal-01"; ?>"><span class="txt">木材の魅力</span></a></li>
						<li><a href="<?php echo $url."#_appeal-02"; ?>"><span class="txt">杉の魅力</span></a></li>
						<li><a href="<?php echo $url."#_appeal-03"; ?>"><span class="txt">桧の魅力</span></a></li>
						<li><a href="<?php echo $url."#_domestic"; ?>"><span class="txt">人と環境に優しい<br class="br">国産材</span></a></li>
						<li><a href="<?php echo $url."#_catalog"; ?>"><span class="txt">商品カタログ</span></a></li>
					</ul>
				</li>
				<?php endif; ?>
				<li class=""><a href="<?php echo home_url("#_catalog"); ?>" class="item"><span class="txt">商品<br class="br">カタログ</span></a></li>
				<?php $url = get_page_url("about"); if($url): ?>
				<li class=""><a href="<?php echo $url; ?>" class="item"><span class="txt">組合概要</span></a>
					<ul class="list --h-opacity">
						<li class=""><a href="<?php echo $url."#_about"; ?>"><span class="txt">協同組合について</span></a></li>
						<li class=""><a href="<?php echo $url."#_greeting"; ?>"><span class="txt">ご挨拶</span></a></li>
						<li class=""><a href="<?php echo $url."#_overview"; ?>"><span class="txt">組合概要</span></a></li>
						<li class=""><a href="<?php echo $url."#_philosophy"; ?>"><span class="txt">経営理念</span></a></li>
						<li class=""><a href="<?php echo $url."#_vision"; ?>"><span class="txt">経営ビジョン</span></a></li>
						<li class=""><a href="<?php echo $url."#_access"; ?>"><span class="txt">アクセス</span></a></li>
					</ul>
				</li>
				<?php endif; ?>
				<?php $url = get_page_url("faq"); if($url): ?>
				<li class=""><a href="<?php echo $url; ?>" class="item"><span class="txt">よくある<br class="br">質問</span></a></li>
				<?php endif; ?>
				<li class=""><a href="<?php echo home_url("news"); ?>" class="item --ff-en"><span class="txt">NEWS</span></a></li>
			</ul>
			<?php $url = get_page_url("contact"); if($url): ?>
			<a href="<?php echo $url; ?>" class="cntBtn _Btn --pc"><span class="icon"></span><span class="txt">お問い合わせ</span></a>
			<?php endif; ?>
			<div id="headerBtn" class="--tab-sp"><span></span><span></span><span></span></div>
		</div>
	</div>
</header>
